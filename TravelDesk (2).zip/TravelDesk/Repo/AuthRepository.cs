﻿using TravelDesk.Context;
using TravelDesk.IRepo;
using TravelDesk.Models;

namespace TravelDesk.Repo
{
    public class AuthRepository : IAuthRepository
    {
        private readonly DbContexts _context;

        public AuthRepository(DbContexts context)
        {
            _context = context;
        }

        public User Authenticate(string email, string password)
        {
            var user = _context.Users.SingleOrDefault(u => u.Email == email && u.Password == password);

            return user; // Return null if user is not found
        }
    }
}
