﻿using Microsoft.EntityFrameworkCore;
using TravelDesk.Context;
using TravelDesk.IRepo;
using TravelDesk.Models;

namespace TravelDesk.Repo
{
    public class UserRepository : IUserRepository
    {
        private readonly DbContexts _context;

        public UserRepository(DbContexts context)
        {
            _context = context;
        }

        public List<User> GetUsers()
        {
            return _context.Users.ToList();
        }

        public User GetUserById(int id)
        {
            return _context.Users.Find(id);
        }

        public User AddUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return user;
        }

        public User UpdateUser(int id, User user)
        {
            var existingUser = _context.Users.Find(id);
            if (existingUser != null)
            {
                existingUser.FirstName = user.FirstName;
                existingUser.LastName = user.LastName;
                existingUser.Address = user.Address;
                existingUser.Email = user.Email;
                existingUser.MobileNum = user.MobileNum;
                existingUser.Password = user.Password;
                existingUser.RoleId = user.RoleId;
                existingUser.ManagerId = user.ManagerId;
                existingUser.ModifiedBy = user.ModifiedBy;
                existingUser.ModifiedOn = user.ModifiedOn;
                existingUser.IsActive = user.IsActive;

                _context.SaveChanges();
            }
            return existingUser;
        }

        public bool DeleteUser(int id)
        {
            var user = _context.Users.Find(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                _context.SaveChanges();
                return true;
            }
            return false;
        }

        //public User Login(string email, string password)
        //{
        //    return _context.Users.FirstOrDefault(x => x.Email == email && x.Password == password);
        //}
    }
}
