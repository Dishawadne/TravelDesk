﻿using TravelDesk.Models;

namespace TravelDesk.IRepo
{
    public interface IAuthRepository
    {
        User Authenticate(string email, string password);
    }
}
